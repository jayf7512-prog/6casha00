//
//  ActivityViewController.swift
//  CashappSpoof


import UIKit

class ActivityViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    let transactions: [(name: String, amount: String, date: String, status: String)] = [
        ("Janice O", "+$25.00", "Yesterday", "Pending"),
        ("Spotify Inc.", "-$14.70", "Friday", "Declined"),
        ("Pch Intelius", "-$35.30", "Friday", "Declined"),
        ("Pch Intelius", "-$35.30", "Saturday", "Declined"),
        ("Numlookup Trial Over", "-$10.00", "Saturday", "Declined")
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        overrideUserInterfaceStyle = .dark
        view.backgroundColor = .black
        title = "Activity"

        let tableView = UITableView(frame: view.bounds, style: .plain)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.backgroundColor = .black
        view.addSubview(tableView)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return transactions.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let item = transactions[indexPath.row]
        cell.textLabel?.text = "\(item.name)  \(item.amount)  \(item.date)  \(item.status)"
        cell.textLabel?.textColor = .white
        cell.backgroundColor = .black
        return cell
    }
}