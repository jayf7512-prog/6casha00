//
//  SceneDelegate.swift
//  CashappSpoof


import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        
        window = UIWindow(windowScene: windowScene)
        window?.overrideUserInterfaceStyle = .dark   // Force dark mode
        
        // Create tab bar
        let tabBarController = UITabBarController()
        
        let moneyVC = BalanceViewController()
        let activityVC = ActivityViewController()
        let payVC = SendViewController()   // or PayViewController if you renamed it
        
        moneyVC.title = "Money"
        activityVC.title = "Activity"
        payVC.title = "Pay"
        
        tabBarController.viewControllers = [moneyVC, activityVC, payVC]
        
        window?.rootViewController = tabBarController
        window?.makeKeyAndVisible()
    }
}