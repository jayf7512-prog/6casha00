//
//  BalanceViewController.swift
//  CashappSpoof
//
//
//

import UIKit

class BalanceViewController: UIViewController {

    private var balanceLabel: UILabel!
    private var balance: Double = 0.08   // Starting balance – change this

    override func viewDidLoad() {
        super.viewDidLoad()
        overrideUserInterfaceStyle = .dark
        setupUI()
    }

    func setupUI() {
        view.backgroundColor = .black

        // --- "Money" Header ---
        let titleLabel = UILabel()
        titleLabel.text = "Money"
        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 34, weight: .bold)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleLabel)

        // --- Locked / User Tag ---
        let lockedLabel = UILabel()
        lockedLabel.text = "Locked  $liljay27k"
        lockedLabel.textColor = .gray
        lockedLabel.font = UIFont.systemFont(ofSize: 14)
        lockedLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(lockedLabel)

        // --- "Cash balance •• 5218" ---
        let cashBalanceHeader = UILabel()
        cashBalanceHeader.text = "Cash balance •• 5218"
        cashBalanceHeader.textColor = .gray
        cashBalanceHeader.font = UIFont.systemFont(ofSize: 14)
        cashBalanceHeader.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(cashBalanceHeader)

        // --- Balance Label ---
        balanceLabel = UILabel()
        updateBalanceLabel()
        balanceLabel.textColor = .white
        balanceLabel.font = UIFont.systemFont(ofSize: 40, weight: .bold)
        balanceLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(balanceLabel)

        // --- Add Money Button ---
        let addButton = UIButton(type: .system)
        addButton.setTitle("Add money", for: .normal)
        addButton.backgroundColor = .systemGreen
        addButton.setTitleColor(.white, for: .normal)
        addButton.layer.cornerRadius = 8
        addButton.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        addButton.translatesAutoresizingMaskIntoConstraints = false
        addButton.addTarget(self, action: #selector(addMoneyTapped), for: .touchUpInside)
        view.addSubview(addButton)

        // --- Withdraw Button ---
        let withdrawButton = UIButton(type: .system)
        withdrawButton.setTitle("Withdraw", for: .normal)
        withdrawButton.backgroundColor = UIColor(white: 0.2, alpha: 1)
        withdrawButton.setTitleColor(.white, for: .normal)
        withdrawButton.layer.cornerRadius = 8
        withdrawButton.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        withdrawButton.translatesAutoresizingMaskIntoConstraints = false
        withdrawButton.addTarget(self, action: #selector(withdrawTapped), for: .touchUpInside)
        view.addSubview(withdrawButton)

        // --- Green Status ---
        let statusLabel = UILabel()
        statusLabel.text = "Green status  In progress"
        statusLabel.textColor = .systemGreen
        statusLabel.font = UIFont.systemFont(ofSize: 14)
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(statusLabel)

        // --- Savings Section ---
        let savingsLabel = UILabel()
        savingsLabel.text = "Savings"
        savingsLabel.textColor = .white
        savingsLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        savingsLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(savingsLabel)

        let savingsAmount = UILabel()
        savingsAmount.text = "$0.21"
        savingsAmount.textColor = .white
        savingsAmount.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        savingsAmount.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(savingsAmount)

        let savingsRate = UILabel()
        savingsRate.text = "Up to 3.25% interest"
        savingsRate.textColor = .gray
        savingsRate.font = UIFont.systemFont(ofSize: 14)
        savingsRate.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(savingsRate)

        // --- "More for you" Section ---
        let moreLabel = UILabel()
        moreLabel.text = "More for you"
        moreLabel.textColor = .white
        moreLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        moreLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(moreLabel)

        let stocksLabel = UILabel()
        stocksLabel.text = "Stocks with"
        stocksLabel.textColor = .gray
        stocksLabel.font = UIFont.systemFont(ofSize: 14)
        stocksLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stocksLabel)

        // --- Layout Constraints ---
        NSLayoutConstraint.activate([
            // Header
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

            lockedLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4),
            lockedLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

            // Cash balance header
            cashBalanceHeader.topAnchor.constraint(equalTo: lockedLabel.bottomAnchor, constant: 20),
            cashBalanceHeader.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

            // Balance
            balanceLabel.topAnchor.constraint(equalTo: cashBalanceHeader.bottomAnchor, constant: 4),
            balanceLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

            // Buttons
            addButton.topAnchor.constraint(equalTo: balanceLabel.bottomAnchor, constant: 16),
            addButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            addButton.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant: -8),
            addButton.heightAnchor.constraint(equalToConstant: 48),

            withdrawButton.topAnchor.constraint(equalTo: balanceLabel.bottomAnchor, constant: 16),
            withdrawButton.leadingAnchor.constraint(equalTo: view.centerXAnchor, constant: 8),
            withdrawButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            withdrawButton.heightAnchor.constraint(equalToConstant: 48),

            // Status
            statusLabel.topAnchor.constraint(equalTo: addButton.bottomAnchor, constant: 12),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

            // Savings
            savingsLabel.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 24),
            savingsLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            savingsAmount.centerYAnchor.constraint(equalTo: savingsLabel.centerYAnchor),
            savingsAmount.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            savingsRate.topAnchor.constraint(equalTo: savingsLabel.bottomAnchor, constant: 2),
            savingsRate.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

            // More for you
            moreLabel.topAnchor.constraint(equalTo: savingsRate.bottomAnchor, constant: 24),
            moreLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stocksLabel.topAnchor.constraint(equalTo: moreLabel.bottomAnchor, constant: 2),
            stocksLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20)
        ])
    }

    // MARK: - Actions

    @objc func addMoneyTapped() {
        let alert = UIAlertController(title: "Add Money", message: "Enter amount to add", preferredStyle: .alert)
        alert.addTextField { textField in
            textField.placeholder = "0.00"
            textField.keyboardType = .decimalPad
        }
        let addAction = UIAlertAction(title: "Add", style: .default) { _ in
            guard let text = alert.textFields?.first?.text,
                  let amount = Double(text), amount > 0 else { return }
            self.balance += amount
            self.updateBalanceLabel()
        }
        alert.addAction(addAction)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    @objc func withdrawTapped() {
        let alert = UIAlertController(title: "Withdraw", message: "Enter amount to withdraw", preferredStyle: .alert)
        alert.addTextField { textField in
            textField.placeholder = "0.00"
            textField.keyboardType = .decimalPad
        }
        let withdrawAction = UIAlertAction(title: "Withdraw", style: .default) { _ in
            guard let text = alert.textFields?.first?.text,
                  let amount = Double(text), amount > 0 else { return }
            if amount > self.balance {
                let errorAlert = UIAlertController(title: "Insufficient Funds", message: "You don't have that much.", preferredStyle: .alert)
                errorAlert.addAction(UIAlertAction(title: "OK", style: .default))
                self.present(errorAlert, animated: true)
                return
            }
            self.balance -= amount
            self.updateBalanceLabel()
        }
        alert.addAction(withdrawAction)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    private func updateBalanceLabel() {
        balanceLabel.text = String(format: "$%.2f", balance)
    }
}